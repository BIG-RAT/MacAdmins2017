#!/bin/bash

## used to create square png files from single png file
## helpful when creating icons for Xcode apps

theImage="$1"
fileName=$(basename "$1" | sed -e 's/.png//')
username=$(stat -f%Su /dev/console)
mkdir "/Users/$username/Desktop/$fileName.iconset"

for i in 16 32 128 256 512; do
	newName="icon_"$i"x"$i".png"
	retinaName="icon_"$i"x"$i"@2x.png"
	/bin/cp "$1" "/Users/$username/Desktop/$fileName.iconset/$newName"
	/bin/cp "$1" "/Users/$username/Desktop/$fileName.iconset/$retinaName"
	/usr/bin/sips "/Users/$username/Desktop/$fileName.iconset/$newName" -z $i $i
	/usr/bin/sips "/Users/$username/Desktop/$fileName.iconset/$retinaName" -z $(( i*2 )) $(( i*2 ))
done

/usr/bin/iconutil -c icns "/Users/$username/Desktop/$fileName.iconset"

